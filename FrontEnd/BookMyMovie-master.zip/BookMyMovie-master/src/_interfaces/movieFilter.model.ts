export interface movieFilter{
    title:string;
    rating:number;
    tags:string[];
}