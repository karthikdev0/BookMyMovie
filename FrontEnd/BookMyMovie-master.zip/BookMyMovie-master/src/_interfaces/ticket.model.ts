export interface Ticket{
    ticketId:number;
    theatreName:string;
    numOfSeats:number;
    price:number;
    ticketClass:string;
}