export interface userDetails{
    userId: number,
    firstName: string,
    lastName: string,
    email: string,
    dateOfBirth: Date,
    gender: string,
    userModelId: number
  }