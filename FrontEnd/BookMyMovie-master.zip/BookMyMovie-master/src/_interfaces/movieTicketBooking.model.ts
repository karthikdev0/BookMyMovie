export interface movieTicketBooking{
    numOfseat: number,
    movieId: number,
    userId: number,
    theatreId: number,
    movieDate:Date,
    seatNumber:string[],
    screenId: number
}