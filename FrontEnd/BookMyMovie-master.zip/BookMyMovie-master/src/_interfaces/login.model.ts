export interface login{
    userName: string,
    password:string
}