export interface review {
   
        reviewId: number,
        rating: number,
        review_Content : string,
        movieId: number,
        userId: number
      
}