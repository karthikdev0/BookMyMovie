export interface ticketClass{
    key:string;
    value:number;
}