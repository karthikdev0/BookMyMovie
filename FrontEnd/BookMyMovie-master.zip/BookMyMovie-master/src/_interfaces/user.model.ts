export interface user{
    userId:number;
    userName:string;
    password:string;
    firstName:string;
    lastName:string;
    email:string;
    dob:Date;
    gender:string;
    role:string;
  //  userModelId:number
}