export interface seat{
    seatId: number,
    seatNumber: string,
    seatClass: string,
    isSeatBooked: boolean,
    screenId: number,
    isSelected:boolean
}