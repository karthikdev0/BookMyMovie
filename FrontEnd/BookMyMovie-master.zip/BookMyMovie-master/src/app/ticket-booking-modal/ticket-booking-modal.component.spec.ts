import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TicketBookingModalComponent } from './ticket-booking-modal.component';

describe('TicketBookingModalComponent', () => {
  let component: TicketBookingModalComponent;
  let fixture: ComponentFixture<TicketBookingModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TicketBookingModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TicketBookingModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
