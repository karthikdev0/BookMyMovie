import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-ticket',
  templateUrl: './single-ticket.component.html',
  styleUrls: ['./single-ticket.component.css']
})
export class SingleTicketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
