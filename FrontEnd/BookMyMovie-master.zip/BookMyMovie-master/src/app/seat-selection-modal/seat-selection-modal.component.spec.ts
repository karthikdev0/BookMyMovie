import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeatSelectionModalComponent } from './seat-selection-modal.component';

describe('SeatSelectionModalComponent', () => {
  let component: SeatSelectionModalComponent;
  let fixture: ComponentFixture<SeatSelectionModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeatSelectionModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeatSelectionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
