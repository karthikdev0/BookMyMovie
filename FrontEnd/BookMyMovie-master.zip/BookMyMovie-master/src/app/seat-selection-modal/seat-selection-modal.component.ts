import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seat-selection-modal',
  templateUrl: './seat-selection-modal.component.html',
  styleUrls: ['./seat-selection-modal.component.css']
})
export class SeatSelectionModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
