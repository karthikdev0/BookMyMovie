import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertMovieRecordComponent } from './insert-movie-record.component';

describe('InsertMovieRecordComponent', () => {
  let component: InsertMovieRecordComponent;
  let fixture: ComponentFixture<InsertMovieRecordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InsertMovieRecordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertMovieRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
